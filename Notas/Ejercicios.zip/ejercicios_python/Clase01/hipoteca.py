# hipoteca.py
# Archivo de ejemplo
# Ejercicio de hipoteca
