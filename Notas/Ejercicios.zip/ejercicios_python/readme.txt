esta carpeta contiene subcarpetas ordenadas por clase y otra con los archivos de datos de toda la materia
